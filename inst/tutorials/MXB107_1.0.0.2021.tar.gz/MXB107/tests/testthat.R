library(testthat)
library(mxb107.test)

test_check("mxb107.test")
